export const API_URL = "http://localhost:5000/api";

export async function registerUser(name, email, password) {
  try {
    const res = await fetch(`${API_URL}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password }),
    });
    const data = await res.json();
    return data;
  } catch (err) {
    console.error("Register API error:", err);  // 'err' is defined here
    return { error: "Network error. Please try again." };
  }
}

export async function loginUser(email, password) {
  try {
    const res = await fetch(`${API_URL}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    return data;
  } catch (err) {
    console.error("Login API error:", err); // 'err' is defined here
    return { error: "Network error. Please try again." };
  }
}

export async function getUser(token) {
  try {
    const res = await fetch(`${API_URL}/dashboard`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    return data;
  } catch (err) {
    console.error("Dashboard API error:", err); // 'err' is defined here
    return { error: "Network error. Please try again." };
  }
}
