const pool = require("./config/db");

async function testDB() {
  try {
    const res = await pool.query("SELECT NOW()");
    console.log("Database Connected:", res.rows[0]);
  } catch (err) {
    console.error("Connection Error:", err);
  }
}

testDB();
