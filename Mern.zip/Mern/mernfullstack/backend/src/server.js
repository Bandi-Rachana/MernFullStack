import express from "express";
import cors from "cors";
import dotenv from "dotenv";

import authRoutes from "./routes/authRoutes.js"; // your auth routes
import dashboardRoute from "./routes/dashboard.js"; // dashboard route

dotenv.config();

const app = express();

// CORS for frontend
app.use(cors({
  origin: "http://localhost:5173", // Vite frontend
  credentials: true
}));

app.use(express.json()); // parse JSON

// Mount routes
app.use("/api/auth", authRoutes);           // <-- /api/auth/register & /api/auth/login
app.use("/api/dashboard", dashboardRoute);  // <-- /api/dashboard

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on ${PORT}`));
