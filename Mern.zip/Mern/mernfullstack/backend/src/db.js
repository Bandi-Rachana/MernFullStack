import pkg from "pg";
import dotenv from "dotenv";
dotenv.config();

const { Pool } = pkg;

const pool = new Pool({
  user: process.env.DB_USER,       // postgres
  host: process.env.DB_HOST,       // 127.0.0.1
  database: process.env.DB_NAME,   // taskflow
  password: process.env.DB_PASSWORD, // must match your PostgreSQL password
  port: process.env.DB_PORT,       // 5432
});

pool.connect()
  .then(() => console.log("PostgreSQL connected"))
  .catch(err => console.error("DB connection error:", err));

export default pool;
