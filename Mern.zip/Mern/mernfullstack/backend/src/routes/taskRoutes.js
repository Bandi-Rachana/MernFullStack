const express = require("express");
const pool = require("../db");
const auth = require("../middleware/authMiddleware");

const router = express.Router();

router.post("/", auth, async (req, res) => {
  const { title, project_id } = req.body;

  const task = await pool.query(
    "INSERT INTO tasks (title, project_id) VALUES ($1,$2) RETURNING *",
    [title, project_id]
  );

  res.json(task.rows[0]);
});

router.get("/:projectId", auth, async (req, res) => {
  const tasks = await pool.query(
    "SELECT * FROM tasks WHERE project_id=$1",
    [req.params.projectId]
  );

  res.json(tasks.rows);
});

module.exports = router;
