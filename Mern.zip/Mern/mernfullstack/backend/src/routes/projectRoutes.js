const express = require("express");
const pool = require("../db");
const auth = require("../middleware/authMiddleware");

const router = express.Router();

router.post("/", auth, async (req, res) => {
  const { name } = req.body;

  const project = await pool.query(
    "INSERT INTO projects (name, owner_id) VALUES ($1,$2) RETURNING *",
    [name, req.user.id]
  );

  res.json(project.rows[0]);
});

router.get("/", auth, async (req, res) => {
  const projects = await pool.query(
    "SELECT * FROM projects WHERE owner_id=$1",
    [req.user.id]
  );

  res.json(projects.rows);
});

module.exports = router;
